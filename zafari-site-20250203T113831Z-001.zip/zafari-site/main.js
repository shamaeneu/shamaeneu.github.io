var animation = bodymovin.loadAnimation({
    container: document.getElementById('lottie'), // Required
    path: 'json/SZ_Intro_Anim.json', // Required
    renderer: 'svg', // Required
    loop: true, // Optional
    autoplay: true, // Optional
    name: "Intro", // Name for future reference. Optional.
  })